<main class="flex-1 page ql-editor p-5">
    {!! $page->content !!}
</main>
